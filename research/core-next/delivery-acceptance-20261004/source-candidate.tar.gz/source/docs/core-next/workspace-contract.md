# 动态文件视图与增量工作区

本页描述原生桥与共享 StageStore 的工作区接入，试验证据见 [工作区试验](workspace-experiments.md)。目标是让主体通过熟悉的文件命令读取共享信息，同时使未改变的私有正文跨激活复用。信息、行动与完整步骤合同继续由现有 Core 提供。

## 一、接口

公开路径分为 `/world` 共享只读信息、`/workspace` 主体私有可写目录，以及既有受控输出目录。普通 shell 临时目录属于本次激活；持久私有材料须写入 `/workspace`。这项边界在 shell 工具说明中公开。共享挂载经已有 Information 的 actor-bound scope 读取，文件写权限不会授予世界事实写权限；行动继续经 action 门面执行。

可选 `workspace_plugin`，声明共享 StageStore 中的工作区 head 与文件表，并提供 `WorkspaceStore` 服务。它按 actor/path 唯一索引定位当前文件，按 actor/parent/path 索引列目录。主体首次使用时才创建短命 native overlay；休眠主体仅保留 SQL 行和工件引用。`ShellSession` 接受该主体的工作区 lease，恢复 shell-only 状态并重新挂载文件系统。LLMDriver 成功或 waiting 退出前收束工作区；失败不发布完整步骤。ActorStore 的整包工作区 API 已移除，已有运行格式无需迁移。

Information 的 stat/list_files 提供薄 metadata 读取能力，返回目录或文件、原文字节数、相关数据版本和 Ref。SQL 提供者的目录列出真实记录路径，文档读通过已有范围接口；数据集单记录文件返回该记录完整 JSON。整张表保持目录与 `data query` 两种消费入口。特殊动态提供者明确自己的文件表示，目录展开与文件正文无需预铺到解释器。元数据与正文共用权限路由，目录枚举也遵循 discover；不能从拒绝读取的正文推断文件大小。

## 二、持久化

每次激活只含一个原生 OverlayFs，上层是本次写入，下层是共享 SQL 当前文件索引。读取下层会触达对应文件，改动由成熟 overlay 执行，最终导出 upper 与成功删除路径。文件工件先准备，单个 SQL 事务应用删除、最终条目及 shell-only 状态，并登记工件依赖。StageStore complete 保存该事务变化和不可变工件；恢复沿既有完整步骤协议取得文件索引。下次激活直接查当前索引，不连接前一次 overlay。

删除与重命名由原生文件系统决定行为；提交层把删除集合先应用，再写入最终 upper。目录删除按已登记的私有路径范围删除子项。文件元数据、符号链接和重命名目标必须完整保留，故原生默认目录不能通过名称黑名单清除。对仅被读过的原始文件，upper 不包含它的正文。shell 状态每次仍有少量编码成本，可直接保存；无需引入内容指纹。

私有文件被修改时，原生接口可能读取和复制整个文件，增量单位为文件。频繁追加超大私有文件仍有明确成本。共享信息则使用有界文件投影：ShellSession 的 projection_file_bytes 默认 65536，projection_page_size 默认 100，可设为 2–100。大文档显示为目录，@manifest.json 给出原文字节数、版本和分片路径；@parts- 目录提供独立 base64 字节片，逐片解码后按序拼接还原原文；UTF-8 文本可直接读取 @text- 目录并按序拼接。分片目录分层，单目录项数由配置约束。共享数据目录的 manifest 给出 total 和 next_directory，沿 @page- 继续目录可遍历全部记录，提供者版本变化则明确拒绝续读。原始文件名中的 % 和 @ 转义后显示。范围读取和下推分析继续使用 data 命令。

## 三、生命周期

文件回调在调用者事件循环执行，检查 scope 后读取，等待结束后再次检查。lease 关闭时取消并等待自身回调，完成收束后才释放借用的 StageStore 和 Information。原生 ABI 只连接文件系统，业务授权仍由已有服务决定。取消执行、关闭 scope 和关闭运行分别有独立消费者测试。

一次文件读取若分段获取文档，所有段必须属于同一数据版本；变化明确报错，避免组成混合文件。共享目录读取在同一个请求内保持游标版本；后续命令可以看到新的合法业务状态。私有文件提交由 actor lease 限定身份，提交失败不把 Thread 标为成功。完整步骤恢复后新 lease 使用新的 run 身份。

## 四、交付

原生模块作为 shell 的可选 wheel 依赖，基础 rule/SQLite 安装无需 Rust、Bashkit 或该模块。源码构建使用成熟 PyO3/maturin，提供 macOS arm64 与实际 Linux 运行机平台 wheel；CI 至少执行 wheel 安装后 capsule、scope 和真实 LLMDriver 工作区恢复测试。源码分发需要 Rust 工具链，其成本与普通 wheel 安装区分说明。平台构建和干净安装证据见 [安装说明](installation.md)；公共发行状态由 [TODO](TODO.md) 记录。

对应验收覆盖原生桥、StageStore 工作区索引与完整点恢复、Information 动态文件消费、真实 LLMDriver 跨激活、安装及规模。验收条件包括未改 8 MiB 工作区连续激活正文增量为零、改动小文件不读取无关大文件、删除重命名与旧点恢复逐值一致、1,000 个休眠主体只激活固定 k 个时无预建解释器，以及用户可取得全部共享记录和正文。性能判断同时保留大文件 copy-up、大目录枚举与 shell 状态编码的实测下界。

文件级增量、有界共享投影、主体隔离、恢复和平台消费者的实际执行范围见 [独立验收记录](../../research/core-next/acceptance-20261004/status.md)；下节历史规模数字按其工件中的源码身份解释。


## 五、规模

`benchmarks/core_next_workspace_product.py` 为每个目录规模启动独立进程。100、10,000、50,000 条目录的显式 ls 分别耗时约 17.5、36.4、149.5 ms，进程 RSS 高水位增加约 3.0、7.9、27.5 MB；正文读取均为零字节。目录枚举明确与本次所请求的条目数相关。原始数据在 `research/core-next/workspace-product-scale.json`；高水位增量不等同于对象精确分配量。

每组包含 1,000 个主体，实际创建一个 shell；8 MiB 未改文件连续十次激活产生零字节新正文工件，每次仍写小型 shell 状态和工作区根元数据。该结果验证冷文件复用，未证明同时激活全部主体的总驻留上界。

WorkspaceStore 的数据前提是同库 Actor schema，构造时以零行查询确认。Workspace 安装仅获取 StageStore；compose 在安装任何服务前已汇集并建立全部 schema 和初始主体，因而主体驱动工厂可声明依赖 workspace 服务。FK 继续约束文件所属主体，缺失 Actor schema 在安装时报错；恢复使用同一 schema 校验与工厂装配，服务安装顺序无需承担数据初始化职责。
